# dpre.py

import pandas as pd
from sklearn.preprocessing import LabelEncoder
# Function to perform data preprocessing steps
def data_preprocessing(df):
    label_encoder = LabelEncoder()
    df["model"] = label_encoder.fit_transform(df["model"])
    df["transmission"] = label_encoder.fit_transform(df["transmission"])
    df["fuelType"] = label_encoder.fit_transform(df["fuelType"])
    #replace with mean
    mean_tax = df['tax'].mean()
    df['tax'].fillna(mean_tax, inplace=True) 
    #replace with mean
    mean_engine = df['engineSize'].mean()
    df['engineSize'].fillna(mean_engine, inplace=True)

    
    # Save the resulting dataframe as a new CSV file
    df.to_csv("/salma/docker_project/res_dpre.csv", index=False)

if __name__ == "__main__":
    # Load the dataset
    df = pd.read_csv("/salma/docker_project/loaded_dataset.csv")
    data_preprocessing(df)
    print("Data preprocessing completed!")
    # Invoke the next Python file
    exec(open("/salma/docker_project/eda_after.py").read())
