#!/bin/bash
docker cp dockerr:/salma/docker_project/res_dpre.csv   "C://Users//salma elbadry//Desktop//docker_project//service-result"
docker cp dockerr:/salma/docker_project/eda_before_PRE.txt   "C://Users//salma elbadry//Desktop//docker_project//service-result"
docker cp dockerr:/salma/docker_project/eda_eda_after_PRE.txt   "C://Users//salma elbadry//Desktop//docker_project//service-result"
docker cp dockerr:/salma/docker_project/regression_results.txt   "C://Users//salma elbadry//Desktop//docker_project//service-result"
docker cp dockerr:/salma/docker_project/vis1.png   "C://Users//salma elbadry//Desktop//docker_project//service-result"
docker cp dockerr:/salma/docker_project/vis2.png   "C://Users//salma elbadry//Desktop//docker_project//service-result"
docker cp dockerr:/salma/docker_project/vis3.png   "C://Users//salma elbadry//Desktop//docker_project//service-result"
docker cp dockerr:/salma/docker_project/vis4.png   "C://Users//salma elbadry//Desktop//docker_project//service-result"
docker cp dockerr:/salma/docker_project/vis5.png   "C://Users//salma elbadry//Desktop//docker_project//service-result"
docker cp dockerr:/salma/docker_project/vis6.png   "C://Users//salma elbadry//Desktop//docker_project//service-result"
docker cp dockerr:/salma/docker_project/vis7.png   "C://Users//salma elbadry//Desktop//docker_project//service-result"
docker cp dockerr:/salma/docker_project/vis8.png   "C://Users//salma elbadry//Desktop//docker_project//service-result"
docker cp dockerr:/salma/docker_project/vis9.png   "C://Users//salma elbadry//Desktop//docker_project//service-result"
docker cp dockerr:/salma/docker_project/vis10.png   "C://Users//salma elbadry//Desktop//docker_project//service-result"


