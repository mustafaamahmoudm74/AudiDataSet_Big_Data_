from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.tree import DecisionTreeRegressor
from sklearn.linear_model import Lasso
from sklearn.neighbors import KNeighborsRegressor
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.preprocessing import MinMaxScaler
import numpy as np
import pandas as pd

# Assume df is your DataFrame and y is your target variable
df=pd.read_csv("/salma/docker_project/res_dpre.csv")
x = df.drop(['price'], axis=1)  # Check for case sensitivity
df.columns = df.columns.str.strip()  # Remove leading/trailing whitespaces from column names
y = df['price']
# Encoding categorical columns
le = LabelEncoder()
columns_to_encode = ['model', 'transmission', 'fuelType']

for col in columns_to_encode:
    df[col] = le.fit_transform(df[col])

# Normalize the features
scaler = MinMaxScaler()
x = df.drop(['price'], axis=1)
df_normalized = pd.DataFrame(scaler.fit_transform(x), columns=x.columns)

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(df_normalized, y, test_size=0.2, random_state=42)

# Define the models
models = {
    'Gradient Boosting Regressor': GradientBoostingRegressor(random_state=42),
    'Decision Tree Regressor': DecisionTreeRegressor(random_state=42),
    'Lasso Regression': Lasso(alpha=0.1),
    'KNeighbors Regressor': KNeighborsRegressor(n_neighbors=5),
    
}

# Create a file to save the results
with open("regression_results.txt", "w") as file:
    for model_name, model in models.items():
        # Fit the model
        model.fit(X_train, y_train)

        # Predictions on the test set
        y_pred_test = model.predict(X_test)

        # R-squared on the test set
        r2_test = r2_score(y_test, y_pred_test)
        mse = mean_squared_error(y_test, y_pred_test)
        # Write results to the file
        file.write(f"\nResults for: {model_name}\n")
        file.write(f"R-squared on Test Set: {r2_test}\n")
        file.write(f"mean_square_error: {mse}\n")
