import sys
import pandas as pd

# Function to perform exploratory data analysis
def exploratory_data_analysis(df, output_file):
    # Redirect stdout to the output file
    sys.stdout = open(output_file, 'w')

    print(df.head(10))
    print(df.describe())
    print(df.info())
    print(df.isna().sum())
    print(df.duplicated().sum())
    print(df.tax.unique())

    # Reset stdout to the default (console)
    sys.stdout = sys.__stdout__

if __name__ == "__main__":
    # Load the preprocessed dataset
    df = pd.read_csv("/salma/docker_project/loaded_dataset.csv")
    
    # Specify the output file for redirected prints
    output_file = "/salma/docker_project/eda_before_PRE.txt"
    
    # Perform exploratory data analysis and save prints to the file
    exploratory_data_analysis(df, output_file)
    
    print("Exploratory data analysis completed _before!")
    

