import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns
df = pd.read_csv('/salma/docker_project/res_dpre.csv')


sns.countplot(x='transmission', data=df, palette='viridis')
# Save the visualization as an image
plt.savefig('/salma/docker_project/vis1.png')

df['price'] = pd.to_numeric(df['price'], errors='coerce')

result = df.groupby('year')['price'].mean()

result.plot(kind="bar")

plt.savefig('/salma/docker_project/vis2.png')

plt.figure(figsize=(10, 6))
plt.scatter(df['year'], df['price'])
plt.title('Scatter Plot for Price vs Year')
plt.xlabel('Year')
plt.ylabel('Price')
plt.savefig('/salma/docker_project/vis3.png')

plt.figure(figsize=(10, 6))
plt.hist(df['price'], bins=20, color='skyblue', edgecolor='black')
plt.title('Histogram for Car Prices')
plt.xlabel('Price')
plt.ylabel('Frequency')
plt.savefig('/salma/docker_project/vis4.png')

plt.figure(figsize=(12, 8))
sns.boxplot(x='fuelType', y='price', data=df)
plt.title('Box Plot for Price by Fuel Type')
plt.xlabel('Fuel Type')
plt.ylabel('Price')
plt.savefig('/salma/docker_project/vis5.png')

df['year'] = df['year'].astype(str)  # يمكن تحويل السنة إلى نص لتجنب تحويلها إلى فئات رقمية.

plt.figure(figsize=(10, 6))
df.groupby('year')['price'].mean().plot(kind='bar', color='lightcoral')
plt.title('Average Price by Year')
plt.xlabel('Year')
plt.ylabel('Average Price')
plt.savefig('/salma/docker_project/vis6.png')

sns.pairplot(df[['price', 'mileage', 'mpg']])
plt.title('Pair Plot for Price, Mileage, and MPG')
plt.savefig('/salma/docker_project/vis7.png')

plt.figure(figsize=(10, 6))
sns.countplot(x='transmission', data=df, palette='viridis')
plt.title('Count Plot for Transmission Types')
plt.xlabel('Transmission Type')
plt.ylabel('Count')
plt.savefig('/salma/docker_project/vis8.png')

plt.figure(figsize=(10, 6))
plt.scatter(df['mileage'], df['price'], color='coral', alpha=0.7)
plt.title('Scatter Plot for Mileage and Price')
plt.xlabel('Mileage')
plt.ylabel('Price')
plt.savefig('/salma/docker_project/vis9.png')

plt.figure(figsize=(10, 6))
df.groupby('fuelType')['price'].mean().sort_values().plot(kind='barh', color='lightgreen')
plt.title('Average Price by Fuel Type')
plt.xlabel('Average Price')
plt.ylabel('Fuel Type')
plt.savefig('/salma/docker_project/vis10.png')