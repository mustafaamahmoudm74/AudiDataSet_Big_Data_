# load.py
import pandas as pd
def load_dataset(file_path):
    df = pd.read_csv(file_path)
    return df

if __name__ == "__main__":
    dataset_path = "/salma/docker_project/audi.csv"
    df = load_dataset(dataset_path)
    df.to_csv("/salma/docker_project/loaded_dataset.csv", index=False)
    print("Dataset loaded successfully!")
    # Invoke the next Python file
    exec(open("/salma/docker_project/eda_before.py").read())
    exec(open("/salma/docker_project/dpre.py").read())
